$(document).ready(function($) {

    $('.auth-section').css( 'min-height', $(document).height() - 210);
    $('#profile-area').css( 'min-height', $(document).height() - 214);

    $('.agree-btn').click(function(e){
        e.preventDefault();
        $('#agreement').prop( "checked", true );
        setTimeout(function(){
            $('#agreement_modal').modal('toggle');
        },1000);
    })

    $('.terms-agreements').bind('scroll', function(){
        if( ($(this).scrollTop() + $(this).innerHeight() + 300) >= $(this)[0].scrollHeight ) {
            $('.agree-btn').show();
        }
    });

    $('.nav-tabs-neac li a').click(function(e){
        e.preventDefault();
        var href = $(this).attr('href');
        var href_class = '.'+ href.substring(1);
        var parent = $(this).parents('.transaction-content');
        parent.find('.all').hide();
        parent.find(href_class).show();
        if( href_class == '.all' ) {
            parent.find('.tab-content > div').show();
        }
        parent.find('.tab-no-content').remove();
        if(parent.find(href_class).length == 0) {
            parent.find('.tab-content').append('<p class="tab-no-content bg-white p-3">No item found!</p>') 
        }
    })

    const COLORS = ["#53a36b", "#96770e","#0b4068","#0b4068","#0b4068","#0b4068",]

    function animateElements() {
        $('.progressbar').each(function(i) {
            var elementPos = $(this).offset().top;
            var topOfWindow = $(window).scrollTop();
            var percent = $(this).find('.circle').attr('data-percent');
            var percentage = parseInt(percent, 10) / parseInt(100, 10);
            var animate = $(this).data('animate');
            if (elementPos < topOfWindow + $(window).height() - 30 && !animate) {
                $(this).data('animate', true);
                $(this).find('.circle').circleProgress({
                    startAngle: -Math.PI / 2,
                    value: percent / 100,
                    thickness: 1,
                    fill: {
                        color: COLORS[i],
                    }
                }).on('circle-animation-progress', function(event, progress, stepValue) {
                    $(this).find('div').text((stepValue * 100).toFixed(1) + "%");
                }).stop();
            }
        });
    }

    // Show animated elements
    animateElements();
    $(window).scroll(animateElements);
});


$(document).ready(function(){
    $('.multiple-items').slick({
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 5000,
        fade: true,
        centerPadding: '60px',
        prevArrow: '<i class="fa fa-chevron-right" style="position:absolute;z-index:9;right:.5em;padding:7px 12px 9px 16px;"></i>',
        nextArrow: '<i class="fa fa-chevron-left" style="position:absolute;z-index:8;left:.5em;padding:7px 16px 9px 12px;"></i>'
    });

    $('.logo-wrapper').slick({
        infinite: true,
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        centerPadding: '60px',
        arrows: false,
        draggable: true,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });
    $('#mainCarousel').slick({
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 5000,
        fade: true,
        dots: true,
        prevArrow: '<a class="carousel-control-prev" href="#mainCarousel" data-slide="prev"><i class="fas fa-chevron-left"></i></a>',
        nextArrow: '<a class="carousel-control-next" href="#mainCarousel" data-slide="next"><i class="fas fa-chevron-right"></i></a>'
    });
});

$('.autoplay').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
});



$(document).ready(function(){
    // Summernote
    $('.summer_note').summernote({
      height: 150,
      toolbar: [
        [ 'style', [ 'style' ] ],
        [ 'font', [ 'bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear'] ],
        [ 'fontname', [ 'fontname' ] ],
        [ 'fontsize', [ 'fontsize' ] ],
        [ 'color', [ 'color' ] ],
        [ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
        [ 'table', [ 'table' ] ],
        [ 'insert', [ 'link'] ],
        [ 'view', [ 'undo', 'redo', 'fullscreen', 'codeview', 'help' ] ]
      ],
    });

    $('.summer_note').each(function(){
      var val = $(this).val();
      $(this).summernote('code',val);
    });

    $('.date_picker_js').each(function(){
        var dateToday = false;
        if( $(this).data('disable-previous') == 1 ) {
          dateToday = new Date();
        }
        $(this).daterangepicker({
            format: 'LT',
            singleDatePicker: true,
            showDropdowns: true,
            autoUpdateInput: false,
            minDate: dateToday,
            locale: {
              format : 'MM/DD/YYYY'
            }
        });
    });

    $('.date_picker_js').on('apply.daterangepicker', function(ev, picker) {
        $(this).val(picker.startDate.format('MM/DD/YYYY'));
    });

    $('.time_picker_js').daterangepicker({
        format: 'LT',
        timePicker : true,
        singleDatePicker:true,
        timePicker24Hour : true,
        timePickerIncrement : 30,
        timePickerSeconds : true,
        autoUpdateInput: false,
        locale : {
            format : 'HH:mm:ss A'
        }
    }).on('show.daterangepicker', function(ev, picker) {
            picker.container.find(".calendar-table").hide();
    });
    $('.time_picker_js').on('apply.daterangepicker', function(ev, picker) {
        $(this).val(picker.startDate.format('HH:mm:ss A'));
    });

    $('.date_time_picker_js').daterangepicker({
        format: 'LT',
        timePicker : true,
        singleDatePicker:true,
        timePicker24Hour : true,
        timePickerIncrement : true,
        timePickerSeconds : true,
        autoUpdateInput: false,
        locale: {
          format: 'MM/DD/YYYY HH:mm:ss A'
        },
    });
    $('.date_time_picker_js').on('apply.daterangepicker', function(ev, picker) {
        $(this).val(picker.startDate.format('MM/DD/YYYY HH:mm:ss A'));
    });

    $('.date_range_picker_js').daterangepicker({
      format: 'LT',
      autoUpdateInput: false,
    });
    $('.date_range_picker_js').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
    });

    $('.color_picker_js').colorpicker();
    $('.color_picker_js').on('colorpickerChange', function(event) {
      $(this).find('.fa-square').css('color', event.color.toString());
      $(this).val(event.color.toString());
    });

    $('input[type="file"]').change(function(e){
            var fileName = '';
            for(var x = 0; x < e.target.files.length; x++) {
              fileName += '<small style="display: block;">'+ e.target.files[x].name +'</small>';
            }
            // alert('The file "' + fileName +  '" has been selected.');
            $(this).parents('.col-md-8').append(fileName);
            $(this).parent().css('margin-bottom', '10px');
    });

    $('#birth_date').daterangepicker({
        format: 'LT',
        singleDatePicker: true,
        showDropdowns: true,
        autoUpdateInput: false,
        locale: {
          format : 'MM/DD/YYYY'
        }
    });
    $('#birth_date').on('apply.daterangepicker', function(ev, picker) {
        $(this).val(picker.startDate.format('MM/DD/YYYY'));
    });



    $("#imageUpload").change(function() {
        readURL(this);
    });

    function readURL(input) {      
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#imagePreview').css('background-image', 'url('+e.target.result+')');
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $('#confirm_password, #new_password').keyup(function(){
        if($(this).val() != $('#new_password').val()) {
            $(this).css('border-color', 'red');
            $(this).parent().find('.input-group-text').css('border-color', 'red');
        } 
        else if($(this).val() != $('#confirm_password').val()) {
            $(this).css('border-color', 'red');
            $(this).parent().find('.input-group-text').css('border-color', 'red');
        }
        else {
            $('.input-group-text').css('border-color', 'green');
            $('#confirm_password, #new_password').css('border-color', 'green');
        }
        console.log($(this).val());
    });

    $('.stars-review i').hover(function(){
          var index = $(this).index();
          $('.stars-review i').removeClass('checked');
          $('#rating').val( index+1 );
          for(var x = 0; x <= index; x++) {
            $('.stars-review i').eq(x).addClass('checked');
          }
          var rating = (function(count) {
            switch( count ) {
              case 1:
                return 'Unsatisfactory';
                break;
              case 2:
                return 'Minimally Satisfactory';
                break;
              case 3:
                return 'Fully Successful';
                break;
              case 4:
                return 'Exceeds Fully Successful';
                break;
              case 5:
                return 'Outstanding';
                break;
              default:
                return 'Undecided';
                break;
            }
          })(index+1);
          $('.label').removeAttr('style').text(rating);
    });

    $('#type').change(function(){

        var url = new URL(window.location.href);
        let params = new URLSearchParams(url.search.slice(1));
        params.delete('type');
        params.delete('state');


        var type = $(this).val();
        var state = ($('#state').length) ? '&state=' + $('#state').val() : '0';
        if(type == 'OLD') {
            params += '&type='+type;
        } else if( type == 'NEW' ) {
            params += '&type='+type+state;
        }
        window.location.href = '?' + params;
                                                         
    });

    $('#state').change(function(){

        var url = new URL(window.location.href);
        let params = new URLSearchParams(url.search.slice(1));
        params.delete('state');

        var state = $(this).val();
        params +=  '&state='+$('#state').val();

        window.location.href = '?' + params;
                                                 
    });

    // Ajax

    $.fn.serializeObject = function () {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name] !== undefined) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };

    $('input[name="payment_mode"]').click(function(){
        var datax = $(this).val();
        $('input[name="payment_mode"]').prop('disabled', true);
        $('.total-checkout').html('  loading...');
        $.post('/ajax', {action: 'change_payment', post_data: datax}, function(res){
           var data  = JSON.parse(res);
           var html = `
                        <span class="code">${data.unit}</span> <span class="total">${data.total}</span>
                    `;
            $('.total-checkout, td.price').html(html);
            $('input[name="payment_mode"]').prop('disabled', false);

            for(var x = 0; x < data.cart_item.length; x++) {
                var price = (data.code == 'PHP') ? data.cart_item[x].price * (data.currency.value + data.currency.additional) : data.cart_item[x].price;
                $('.price-'+x+' span.total').text(price.toFixed(2));
                $('.price-'+x+' span.code').text(data.unit);
            }
        });

    });





  



});